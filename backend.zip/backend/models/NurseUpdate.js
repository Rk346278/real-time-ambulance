const mongoose = require("mongoose");

const nurseUpdateSchema = new mongoose.Schema(
  {
    patientId: { type: String, required: true },
    patientName: { type: String, required: true },
    age: { type: Number, required: true },
    conditionSeverity: { type: String, required: true }, 
    immediateRequirement: { type: String, required: true }, 
    notes: { type: String },

    // ⭐ ADD THIS FIELD FOR AI SEVERITY SCORE ⭐
    severityScore: { type: Number, default: 0 }
  },
  { timestamps: true }
);

module.exports = mongoose.model("NurseUpdate", nurseUpdateSchema);
